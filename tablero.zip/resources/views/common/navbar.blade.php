<nav class="navbar navbar-expand-lg fixed-top navbar-light" style="background-color:#c3d6f5;">
    <div class="container-fluid">
        <a href="javascript:void(0)" id="sidebarCollapse" class="btn btn-link">
            <i class="fas fa-ellipsis-v text-dark"></i>
        </a>
        <a class="navbar-brand" href="#">
            <img src="{{ asset('images/icons/logo_minsa.png') }}" style="height:28px;">
        </a>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a id="nv-title" class="nav-link" href="javascript:void(0)">Home</a>
                </li>
            </ul>
        </div>
        <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <i class="fas fa-align-justify"></i>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="nav navbar-nav ml-auto">
                <!--li class="nav-item active">
                    <a class="nav-link" href="#">Page</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Page</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Page</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Page</a>
                </li-->
            </ul>
        </div>
    </div>
</nav>