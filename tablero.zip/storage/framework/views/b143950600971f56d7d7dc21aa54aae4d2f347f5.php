<!DOCTYPE html>
<html>
    <head>
        <title><?php echo e(env('APP_TITLE')); ?></title>
        <?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <style type="text/css">
            #form-hitos {display:none;}
            #dv-table {display:none;}
        </style>
    </head>
    <body>
        <div class="wrapper">
            <?php echo $__env->make('common.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('common.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div id="content">
                <form id="form-matriz" class="container">
                    <div class="row">
                        <div class="col">
                            <h3 class="text-primary mb-2">Matriz de valoración</h3>
                            <p class="text-secondary">Ingrese los valores correspondientes a cada estado de los procesos</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-8 col-offset-2">
                            <table class="table table-striped table-sm">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <?php $__currentLoopData = $cestados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cestado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th><?php echo e($cestado->estado); ?></th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pestados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pestado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($pestado->estado); ?></th>
                                        <?php $__currentLoopData = $cestados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cestado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td>
                                            <input type="text" data-pestado="<?php echo e($pestado->id); ?>" data-cestado="<?php echo e($cestado->id); ?>" data-key="<?php echo e($pestado->id); ?>-<?php echo e($cestado->id); ?>" class="form-control form-control-sm ip-valoracion" style="width:120px">
                                        </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <button id="btn-sv-matriz" class="btn btn-success"><i class="far fa-save"></i> Guardar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="overlay"></div>
        <!-- modals -->
        <!-- scripts -->
        <?php echo $__env->make('common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <script type="text/javascript">
            var ls_puntajes = <?php echo json_encode($puntajes); ?>;
            //
            function MuestraPuntajes() {
                for(var i in ls_puntajes) {
                    var ipuntaje = ls_puntajes[i];
                    $(".ip-valoracion[data-key=" + ipuntaje.pest + "-" + ipuntaje.cest + "]").val(ipuntaje.puntaje);
                }
            }
            //
            function FormMatrizOnSubmit(event) {
                event.preventDefault();
                var inputs = $(".ip-valoracion");
                var arr_pesos = [];
                $.each(inputs, function() {
                    var input = $(this);
                    if(input.val() == "") {
                        alert("Complete todos los valores de la matriz para continuar");
                        return false;
                    }
                    arr_pesos.push({
                        catp: input.data("pestado"),
                        catc: input.data("cestado"),
                        peso: input.val()
                    });
                });
                var p = {
                    _token: "<?php echo e(csrf_token()); ?>",
                    pesos: arr_pesos
                };
                $.post("<?php echo e(url('ajax/estandarizacion/sv-matriz-valoracion')); ?>", p, function(response) {
                    if(response.state == "success") {
                        ls_puntajes = response.data.puntajes;
                        MuestraPuntajes();
                        alert("Se actualizó la matriz de valoración");
                    }
                }, "json");
            }
            //
            $("#form-matriz").on("submit", FormMatrizOnSubmit);
            MuestraPuntajes();
        </script>
    </body>
</html>