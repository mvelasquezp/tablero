<!DOCTYPE html>
<html>
    <head>
        <title><?php echo e(env('APP_TITLE')); ?></title>
        <?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <body>
        <div class="wrapper">
            <?php echo $__env->make('common.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('common.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div id="content"></div>
        </div>
        <div class="overlay"></div>
        <?php echo $__env->make('common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>
</html>