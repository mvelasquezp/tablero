<!DOCTYPE html>
<html>
    <head>
        <title><?php echo e(env('APP_TITLE')); ?></title>
        <?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <style type="text/css">
            #form-hitos {display:none;}
            #dv-table {display:none;}
        </style>
    </head>
    <body>
        <div class="wrapper">
            <?php echo $__env->make('common.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('common.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div id="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-3">
                            <form id="form-tipo" class="alert alert-success mb-4">
                                <div class="row mb-3">
                                    <div class="col">
                                        <label for="reg-tipo">Tipo de proyecto</label>
                                        <select class="form-control form-control-sm" id="reg-tipo">
                                            <option value="0">- Seleccione -</option>
                                            <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tipo->value); ?>"><?php echo e($tipo->text); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col">
                                        <label for="reg-hito">Hito de control</label>
                                        <select class="form-control form-control-sm" id="reg-hito">
                                            <option value="0">- Seleccione -</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row mb-3 mt-4">
                                    <div class="col">
                                        <button class="btn btn-light"><i class="fas fa-chevron-right"></i> Seleccionar</button>
                                    </div>
                                </div>
                            </form>
                            <form id="form-hitos" class="alert alert-warning">
                                <div class="row mb-2">
                                    <div class="col">
                                        <label for="reg-hito">Seleccione un hito</label>
                                        <select class="form-control form-control-sm" id="reg-hito">
                                            <option value="0">- Seleccione -</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col">
                                        <label for="reg-peso">Ingresa el peso</label>
                                        <input type="text" id="reg-peso" class="form-control form-control-sm" placeholder="Ingrese el peso">
                                    </div>
                                </div>
                                <div class="row mb-2 mt-4">
                                    <div class="col">
                                        <button class="btn btn-primary"><i class="fas fa-plus"></i> Agregar hito</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-9">
                            <tag id="dv-table">
                                <table class="table table-sm table-striped">
                                    <thead>
                                        <tr>
                                            <th width="5%">ID</th>
                                            <th width="35%">Proceso</th>
                                            <th width="10%">Peso</th>
                                            <th width="30%">Usu.Registra</th>
                                            <th width="15%">Fe.Registro</th>
                                            <th width="5%"></th>
                                        </tr>
                                    </thead>
                                    <tbody id="procesos-tbody"></tbody>
                                </table>
                            </tag>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- scripts -->
        <?php echo $__env->make('common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <script type="text/javascript">
        </script>
    </body>
</html>