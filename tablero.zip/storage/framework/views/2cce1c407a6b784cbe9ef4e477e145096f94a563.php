<!DOCTYPE html>
<html>
<head>
	<title>Configuración inicial</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>">
</head>
<body>
	<div class="container">
		<div class="row mt-3">
			<form class="col">
				<div class="form-group">
					<label for="tpdocumento">Tipo de documento</label>
					<select class="form-control" id="tpdocumento" name="tpdocumento">
						<option value="DNI">Documento Nacional de Identidad - DNI</option>
						<option value="RUC">Registro Único de Contribuyente - RUC</option>
						<option value="CE">Carné de Extranjería - CE</option>
						<option value="OT">Otros documentos de identidad</option>
					</select>
				</div>
				<div class="form-group">
					<label for="nrdocumento">Número del documento</label>
					<input type="text" class="form-control" id="nrdocumento" name="nrdocumento" placeholder="Ingresar e-mail">
				</div>
				<button type="submit" class="btn btn-primary">Guardar</button>
			</form>
		</div>
	</div>
	<!-- -->
	<script src="<?php echo e(asset('vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/bootstrap/js/popper.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
</body>
</html>