<!DOCTYPE html>
<html>
    <head>
        <title><?php echo e(env('APP_TITLE')); ?></title>
        <?php echo $__env->make('common.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/bootstrap-datepicker/css/bootstrap-datepicker.min.css')); ?>">
        <style type="text/css">
            #form-hitos {display:none;}
            #dv-table {display:none;}
            .table th, .table td{vertical-align:middle !important;}
            #grid-proyectos thead tr th {text-align:center}
            .btn-indicador{border-radius:32px;height:32px;text-align:center;width:32px !important;}
            #fl-busca{display:none;}
        </style>
    </head>
    <body>
        <div class="wrapper">
            <?php echo $__env->make('common.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('common.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div id="content">
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <div class="alert alert-secondary">
                                <form class="form-inline">
                                    <div class="btn-group btn-group-sm mr-4" role="group" aria-label="Basic example">
                                        <button data-tipo="0" type="button" class="btn btn-primary btn-catalogo active">Todos</button>
                                        <button data-tipo="1" type="button" class="btn btn-primary btn-catalogo">ASP</button>
                                        <button data-tipo="2" type="button" class="btn btn-primary btn-catalogo">Terceros</button>
                                    </div>
                                    <label for="fl-atributo" class="mr-2">Buscar por</label>
                                    <select id="fl-atributo" class="form-control form-control-sm mr-2">
                                        <option value="-1" selected disabled>- Seleccione -</option>
                                        <option value="0">Cualquier atributo</option>
                                        <?php $__currentLoopData = $atributos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atributo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($atributo->value); ?>" data-tipo="<?php echo e($atributo->tipo); ?>"><?php echo e($atributo->text); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <tag id="fl-input" class="mr-3"></tag>
                                    <a id="fl-busca" href="#" class="btn btn-sm btn-primary text-light"><i class="fas fa-search"></i> Buscar</a>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col">
                            <table id="grid-proyectos" class="table table-sm table-striped">
                                <thead>
                                    <tr>
                                        <th width="1%">
                                            <!--a href="#" class="btn btn-xs btn-info text-light"><i class="fas fa-search"></i></a-->
                                        </th>
                                        <th width="2%">ID</th>
                                        <th>Tipo proyecto</th>
                                        <th>Tipo orden</th>
                                        <th>N° Expediente</th>
                                        <th>Fecha emisión</th>
                                        <th>Área usuaria</th>
                                        <th>Descripción</th>
                                        <th>Fecha entrega</th>
                                        <th>Valor</th>
                                        <th>N° pagos</th>
                                        <th class="text-danger">% Avance</th>
                                        <th class="text-danger">Indicador</th>
                                        <th class="text-danger">Días vencimiento</th>
                                        <th class="text-danger">Estado actual</th>
                                        <th class="text-danger">Responsable</th>
                                        <th class="text-danger">Observaciones</th>
                                    </tr>
                                    <!--tr class="tr-filtros">
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                    </tr-->
                                </thead>
                                <tbody></tbody>
                            </table>
                            <!-- -->
                            <!--nav aria-label="Navegador">
                                <ul class="pagination pagination-sm justify-content-end">
                                    <li class="page-item disabled">
                                        <a class="page-link" href="#" tabindex="-1">Previous</a>
                                    </li>
                                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                    <li class="page-item">
                                        <a class="page-link" href="#">Next</a>
                                    </li>
                                    <li class="page-item" style="margin-left:20px;">
                                        <a class="page-link bg-success text-light" href="<?php echo e(url('intranet/seguimiento/crea-proyecto')); ?>"><i class="fas fa-plus"></i> Nuevo proyecto</a>
                                    </li>
                                </ul>
                            </nav-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="overlay"></div>
        <!-- modals -->
        <form id="modal-proyecto" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Registro de proyectos</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row mb-3">
                            <div class="col">
                                <label for="form-tipo">Tipo de proyecto</label>
                                <select id="form-tipo" class="form-control form-control-sm">
                                    <option value="0">- Seleccione -</option>
                                </select>
                            </div>
                            <div class="col"></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col">
                                <label for="form-nombre">Descripción proyecto</label>
                                <input type="text" id="form-nombre" class="form-control form-control-sm">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col">
                                <label for="form-expediente">Tipo de proyecto</label>
                                <input type="text" id="form-expediente" class="form-control form-control-sm">
                            </div>
                            <div class="col">
                                <label for="form-hoja-tramite">Hoja de trámite</label>
                                <input type="text" id="form-hoja-tramite" class="form-control form-control-sm">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col">
                                <label for="form-area">Área usuaria</label>
                                <select id="form-area" class="form-control form-control-sm">
                                    <option value="0">- Seleccione -</option>
                                </select>
                            </div>
                            <div class="col">
                                <label for="form-valor">Valor del proyecto</label>
                                <input type="text" id="form-valor" class="form-control form-control-sm">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col">
                                <label for="form-nombre">Observaciones generales</label>
                                <textarea class="form-control form-control-sm" rows="3" style="resize:none;"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="button" class="btn btn-sm btn-primary"><i class="fas fa-save"></i> Guardar</button>
                    </div>
                </div>
            </div>
        </form>
        <!-- modals -->
        <div id="modal-actualiza-hito" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Modal title</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col">
                                <form id="form-actualiza-hito">
                                    <input type="hidden" id="mah-hito" name="hito">
                                    <input type="hidden" id="mah-proyecto" name="proyecto">
                                    <input type="hidden" id="mah-detalle" name="detalle">
                                    <div class="row mb-2">
                                        <div class="col-6">
                                            <label class="mb-1" for="mah-fin">Fecha límite de ejecución</label>
                                            <input type="text" id="mah-fin" name="fin" class="form-control form-control-sm datepicker" placeholder="yyyy-mm-dd">
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-10">
                                            <label class="mb-1" for="mah-documentacion">Control documentario</label>
                                            <select id="mah-documentacion" name="documentacion" class="form-control form-control-sm">
                                                <option value="0" selected disabled>- Seleccione -</option>
                                                <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(strcmp($estado->tipo,"C") == 0): ?>
                                                <option value="<?php echo e($estado->value); ?>"><?php echo e($estado->text); ?></option>
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-10">
                                            <label class="mb-1" for="mah-proceso">Control proceso</label>
                                            <select id="mah-proceso" name="proceso" class="form-control form-control-sm">
                                                <option value="0" selected disabled>- Seleccione -</option>
                                                <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(strcmp($estado->tipo,"P") == 0): ?>
                                                <option value="<?php echo e($estado->value); ?>"><?php echo e($estado->text); ?></option>
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col">
                                            <label class="mb-1" for="mah-observaciones">Observaciones</label>
                                            <textarea id="mah-observaciones" name="observaciones" class="form-control form-control-sm" style="resize:none"></textarea>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div id="col-atributos" class="col"></div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-sm btn-light" data-dismiss="modal">Cerrar</button>
                        <button type="button" class="btn btn-sm btn-primary"><i class="fas fa-save"></i> Actualizar hito</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- scripts -->
        <?php echo $__env->make('common.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <script type="text/javascript" src="<?php echo e(asset('vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('vendor/bootstrap-datepicker/locales/bootstrap-datepicker.es.min.js')); ?>"></script>
        <script type="text/javascript">
            var ls_proyectos = <?php echo json_encode($proyectos); ?>;
            var ls_atributos;
            var curr_catalogo = 0;
            //
            function ListarProyectos() {
                var tbody = $("#grid-proyectos tbody");
                tbody.empty();
                for(var i in ls_proyectos) {
                    var iproyecto = ls_proyectos[i];
                    if(curr_catalogo == 0 || iproyecto.catalogo == curr_catalogo) {
                        tbody.append(
                            $("<tr/>").attr({
                                "id": "tr-" + iproyecto.id,
                                "data-visible": "S",
                                "data-catalogo": iproyecto.catalogo
                            }).addClass("tr-proyecto").append(
                                $("<td/>").append(
                                    $("<a/>").attr({
                                        "href": "#",
                                        "id": "a-" + iproyecto.id,
                                        "data-id": iproyecto.id
                                    }).addClass("btn btn-xs btn-primary text-light").append(
                                        $("<i/>").addClass("fas fa-list-ul")
                                    ).on("click", MuestraHitos)
                                )
                            ).append(
                                $("<td/>").addClass("text-right").html(iproyecto.id)
                            ).append(
                                $("<td/>").html(iproyecto.tipo)
                            ).append(
                                $("<td/>").html(iproyecto.orden)
                            ).append(
                                $("<td/>").html(iproyecto.expediente)
                            ).append(
                                $("<td/>").html(iproyecto.femision)
                            ).append(
                                $("<td/>").html(iproyecto.areausr)
                            ).append(
                                $("<td/>").html(iproyecto.proyecto)
                            ).append(
                                $("<td/>").html(iproyecto.fentrega)
                            ).append(
                                $("<td/>").html(parseFloat(iproyecto.valor).toLocaleString("en-US", { minimumFractionDigits:2, maximumFractionDigits:2 })).addClass("text-right")
                            ).append(
                                $("<td/>").html(iproyecto.armadas).addClass("text-right")
                            ).append(
                                $("<td/>").html(parseFloat(iproyecto.avance).toFixed(2) + "%").addClass("text-right text-danger").css("font-size","1.1em").css("font-weight","bold")
                            ).append(
                                $("<td/>").append(
                                    $("<a/>").attr("href","javascript:void(0)").addClass("btn btn-indicador btn-xs btn-" + iproyecto.indicador)
                                ).addClass("text-center")
                            ).append(
                                $("<td/>").html(iproyecto.diasvence).addClass("text-center text-danger").css("font-size","1.1em").css("font-weight","bold")
                            ).append(
                                $("<td/>").html(iproyecto.estado)
                            ).append(
                                $("<td/>").html(iproyecto.responsable)
                            ).append(
                                $("<td/>").html(iproyecto.hobservaciones)
                            )
                        ).append(
                            $("<tr/>").hide()
                        ).append(
                            $("<tr/>").append(
                                $("<td/>")
                            ).append(
                                $("<td/>").attr("colspan", 16).append(
                                    $("<div/>").attr("id", "dv-" + iproyecto.id)
                                )
                            ).hide()
                        );
                    }
                }
            }
            function ListarAtributos() {
                var form = $("<form/>");
                for(var i in ls_atributos) {
                    var iAtributo = ls_atributos[i];
                    switch(iAtributo.tipo) {
                        case 1:
                        case 2:
                            form.append(
                                $("<div/>").addClass("row mb-2").append(
                                    $("<div/>").addClass("col-6").append(
                                        $("<label/>").addClass("mb-1").attr("for","attr-" + iAtributo.campo).html(iAtributo.nombre)
                                    ).append(
                                        $("<input/>").attr({
                                            "type": "number",
                                            "id": "attr-" + iAtributo.campo,
                                            "placeholder": "Ingrese " + iAtributo.nombre.toLowerCase(),
                                            "data-proyecto": iAtributo.proyecto,
                                            "data-hito": iAtributo.hito,
                                            "data-campo": iAtributo.campo,
                                            "data-detalle": iAtributo.detalle
                                        }).addClass("form-control form-control-sm form-atributo").val(iAtributo.value)
                                    )
                                )
                            );
                            break;
                        case 3:
                            form.append(
                                $("<div/>").addClass("row mb-2").append(
                                    $("<div/>").addClass("col").append(
                                        $("<label/>").addClass("mb-1").attr("for","attr-" + iAtributo.campo).html(iAtributo.nombre)
                                    ).append(
                                        $("<input/>").attr({
                                            "type": "text",
                                            "id": "attr-" + iAtributo.campo,
                                            "placeholder": "Ingrese " + iAtributo.nombre.toLowerCase(),
                                            "data-proyecto": iAtributo.proyecto,
                                            "data-hito": iAtributo.hito,
                                            "data-campo": iAtributo.campo,
                                            "data-detalle": iAtributo.detalle
                                        }).addClass("form-control form-control-sm form-atributo").val(iAtributo.value)
                                    )
                                )
                            );
                            break;
                        case 4:
                            form.append(
                                $("<div/>").addClass("row mb-2").append(
                                    $("<div/>").addClass("col-6").append(
                                        $("<label/>").addClass("mb-1").attr("for","attr-" + iAtributo.campo).html(iAtributo.nombre)
                                    ).append(
                                        $("<input/>").attr({
                                            "type": "text",
                                            "id": "attr-" + iAtributo.campo,
                                            "placeholder": "yyyy-mm-dd",
                                            "data-proyecto": iAtributo.proyecto,
                                            "data-hito": iAtributo.hito,
                                            "data-campo": iAtributo.campo,
                                            "data-detalle": iAtributo.detalle
                                        }).addClass("form-control form-control-sm form-atributo datepicker").datepicker({
                                            autoclose: true,
                                            daysOfWeekHighlighted: [0,6],
                                            format: 'yyyy-mm-dd',
                                            language: 'es',
                                            startView: 0,
                                            startDate: '-1d',
                                            todayHighlight: true,
                                            zIndexOffset: 1030
                                        }).val(iAtributo.value)
                                    )
                                )
                            );
                            break;
                        case 5:
                            form.append(
                                $("<div/>").addClass("row mb-2").append(
                                    $("<div/>").addClass("col-6").append(
                                        $("<label/>").addClass("mb-1").attr("for","attr-" + iAtributo.campo).html(iAtributo.nombre)
                                    ).append(
                                        $("<input/>").attr({
                                            "type": "text",
                                            "id": "attr-" + iAtributo.campo,
                                            "placeholder": "Ingrese " + iAtributo.nombre.toLowerCase(),
                                            "maxlength": 1,
                                            "data-proyecto": iAtributo.proyecto,
                                            "data-hito": iAtributo.hito,
                                            "data-campo": iAtributo.campo,
                                            "data-detalle": iAtributo.detalle
                                        }).addClass("form-control form-control-sm form-atributo").val(iAtributo.value)
                                    )
                                )
                            );
                            break;
                        case 6:
                            form.append(
                                $("<div/>").addClass("row mb-2").append(
                                    $("<div/>").addClass("col-6").append(
                                        $("<label/>").addClass("mb-1").attr("for","attr-" + iAtributo.campo)
                                    ).append(
                                        $("<input/>").attr({
                                            "type": "checkbox",
                                            "id": "attr-" + iAtributo.campo,
                                            "data-proyecto": iAtributo.proyecto,
                                            "data-hito": iAtributo.hito,
                                            "data-campo": iAtributo.campo,
                                            "data-detalle": iAtributo.detalle
                                        }).addClass("form-control form-control-sm form-atributo").prop("checked", iAtributo.value == "S")
                                    )
                                )
                            );
                            break;
                        default: break;
                    }
                }
                $("#col-atributos").empty().append(form);
            }
            //
            function MuestraHitos(event) {
                event.preventDefault();
                var a = $(this);
                var id = a.data("id");
                $("#dv-" + id).empty().append(
                    $("<p/>").html("Cargando datos del proyecto. Por favor, espere...")
                ).parent().parent().toggle();
                var p = {
                    _token: "<?php echo e(csrf_token()); ?>",
                    proyecto: id
                };
                $.post("<?php echo e(url('ajax/control/ls-hitos-proyecto')); ?>", p, function(response) {
                    if(response.state == "success") {
                        var tbody = $("<tbody/>");
                        var ls_hitos = response.data.hitos;
                        for(var i in ls_hitos) {
                            var iHito = ls_hitos[i];
                            tbody.append(
                                $("<tr/>").append(
                                    $("<td/>").append(
                                        $("<a/>").attr({
                                            "href": "#",
                                            "data-hito": iHito.hid,
                                            "data-id": iHito.id,
                                            "data-proyecto": iHito.pid,
                                            "data-descripcion": iHito.hito,
                                            "data-toggle": "modal",
                                            "data-target": "#modal-actualiza-hito"
                                        }).append(
                                            $("<i/>").addClass("fas fa-sync-alt")
                                        ).addClass("btn btn-xs btn-success")
                                    ).addClass("text-light")
                                ).append(
                                    $("<td/>").html(iHito.hito)
                                ).append(
                                    $("<td/>").html(iHito.avance + "%").addClass("text-right text-danger").css("font-size","1.1em").css("font-weight","bold")
                                ).append(
                                    $("<td/>").append(
                                        $("<a/>").attr("href","javascript:void(0)").addClass("btn btn-indicador btn-xs btn-" + iHito.indicador)
                                    ).addClass("text-center")
                                ).append(
                                    $("<td/>").html(iHito.fin).addClass("text-right")
                                ).append(
                                    $("<td/>").html(iHito.diasvcto).addClass("text-center")
                                ).append(
                                    $("<td/>").html(iHito.responsable)
                                ).append(
                                    $("<td/>").html(iHito.nombre)
                                ).append(
                                    $("<td/>").html(iHito.edocumentacion).css("font-weight","bold")
                                ).append(
                                    $("<td/>").html(iHito.eproceso).css("font-weight","bold")
                                ).append(
                                    $("<td/>").html(iHito.observaciones).css("font-weight","bold")
                                )
                            );
                        }
                        $("#dv-" + id).empty().append(
                            $("<table/>").append(
                                $("<thead/>").append(
                                    $("<tr/>").append(
                                        $("<th/>").html("")
                                    ).append(
                                        $("<th/>").html("Hito de control")
                                    ).append(
                                        $("<th/>").html("% Avance")
                                    ).append(
                                        $("<th/>").html("Indicador")
                                    ).append(
                                        $("<th/>").html("Fecha límite")
                                    ).append(
                                        $("<th/>").html("Días vcto.")
                                    ).append(
                                        $("<th/>").html("Responsable")
                                    ).append(
                                        $("<th/>").html("")
                                    ).append(
                                        $("<th/>").html("Control documentario")
                                    ).append(
                                        $("<th/>").html("Control del proceso")
                                    ).append(
                                        $("<th/>").html("Observaciones")
                                    )
                                ).addClass("thead-dark")
                            ).append(tbody).addClass("table table-sm table-striped")
                        );
                    }
                    else alert(response.msg);
                }, "json");
            }
            function ModalActualizaHitoOnShow(args) {
                var dataset = args.relatedTarget.dataset;
                //
                document.getElementById("mah-fin").value = "";
                document.getElementById("mah-observaciones").value = "";
                $("#mah-documentacion option[value=0]").prop("selected", true);
                $("#mah-proceso option[value=0]").prop("selected", true);
                //
                $("#modal-actualiza-hito .modal-header .modal-title").html(dataset.descripcion);
                var p = {
                    _token: "<?php echo e(csrf_token()); ?>",
                    proyecto: dataset.proyecto,
                    hito: dataset.hito,
                    id: dataset.id
                };
                $.post("<?php echo e(url('ajax/control/ls-estado-hito')); ?>", p, function(response) {
                    if(response.state == "success") {
                        var estado = response.data.estado;
                        document.getElementById("mah-hito").value = dataset.hito;
                        document.getElementById("mah-proyecto").value = dataset.proyecto;
                        document.getElementById("mah-detalle").value = dataset.id;
                        document.getElementById("mah-fin").value = estado.fin;
                        document.getElementById("mah-observaciones").value = estado.observaciones;
                        $("#mah-documentacion option[value=" + estado.edocumentacion + "]").prop("selected", true);
                        $("#mah-proceso option[value=" + estado.eproceso + "]").prop("selected", true);
                        //escribe el formulario de atributos
                        ls_atributos = response.data.atributos;
                        ListarAtributos();
                    }
                    else alert(response.msg);
                }, "json");
            }
            function ActualizarHito(event) {
                event.preventDefault();
                var atributos = [];
                var extras = $(".form-atributo");
                $.each(extras, function() {
                    var ipextra = $(this);
                    atributos.push({
                        aproyecto: ipextra.data("proyecto"),
                        ahito: ipextra.data("hito"),
                        acampo: ipextra.data("campo"),
                        adetalle: ipextra.data("detalle"),
                        avalor: ipextra.val()
                    });
                });
                var p = {
                    _token: "<?php echo e(csrf_token()); ?>",
                    hito: document.getElementById("mah-hito").value,
                    proyecto: document.getElementById("mah-proyecto").value,
                    detalle: document.getElementById("mah-detalle").value,
                    fin: document.getElementById("mah-fin").value,
                    documentacion: document.getElementById("mah-documentacion").value,
                    proceso: document.getElementById("mah-proceso").value,
                    observaciones: document.getElementById("mah-observaciones").value,
                    atributos: atributos
                };
                $.post("<?php echo e(url('ajax/control/upd-estado-hito')); ?>", p, function(response) {
                    if(response.state == "success") {
                        ls_proyectos = response.data.proyectos;
                        $("#modal-actualiza-hito").modal("hide");
                        ListarProyectos();
                        $("#a-" + p.proyecto).trigger("click");
                    }
                    else alert(response.msg);
                }, "json");
            }
            function flAtributoOnChange(event) {
                var tipo = $("#fl-atributo option:selected").data("tipo");
                $("#fl-busca").show();
                var input = $("<input/>").attr({
                    "id": "fl-value",
                    "placeholder": "Ingrese valor",
                    "data-tipo": tipo
                }).addClass("form-control form-control-sm");
                switch(tipo) {
                    case 1:
                    case 2:
                        input.attr("type", "number").width(80);
                        break;
                    case 3:
                        input.attr("type", "text").width(320);
                        break;
                    case 4:
                        input.attr("type", "text").datepicker({
                            autoclose: true,
                            daysOfWeekHighlighted: [0,6],
                            format: 'yyyy-mm-dd',
                            language: 'es',
                            startView: 0,
                            todayHighlight: true,
                            zIndexOffset: 1030
                        }).attr("placeholder", "yyyy-mm-dd").width(100);
                        break;
                    case 5:
                        input.attr({
                            "type": "text",
                            "maxlength": 1
                        }).width(60);
                        break;
                    case 6:
                        input.attr({
                            "type": "text",
                            "maxlength": 1
                        }).width(40);
                        break;
                    default: break;
                }
                $("#fl-input").empty().append(input);
            }
            function BuscarAtributo(event) {
                event.preventDefault();
                var texto = document.getElementById("fl-value").value;
                if(texto != "") {
                    var p = {
                        _token: "<?php echo e(csrf_token()); ?>",
                        tipo: $("#fl-value").data("tipo"),
                        texto: texto
                    };
                    $.post("<?php echo e(url('ajax/control/fl-busca-campo')); ?>", p, function(response) {
                        $("#grid-proyectos tbody tr").hide();
                        if(response.state == "success") {
                            var filas = response.data.proyectos;
                            for(var i in filas) {
                                var ifila = filas[i];
                                $("#tr-" + ifila.id).show();
                            }
                        }
                        else alert(response.msg);
                    }, "json");
                }
                else $("#grid-proyectos tbody .tr-proyecto").show();
            }
            function btnCatalogoOnClick(event) {
                event.preventDefault();
                var a = $(this);
                $(".btn-catalogo.active").removeClass("active");
                a.addClass("active");
                curr_catalogo = a.data("tipo");
                ListarProyectos();
            }
            //
            ListarProyectos();
            $("#modal-actualiza-hito").on("show.bs.modal", ModalActualizaHitoOnShow);
            $(".datepicker").datepicker({
                autoclose: true,
                daysOfWeekHighlighted: [0,6],
                format: 'yyyy-mm-dd',
                language: 'es',
                startView: 0,
                startDate: '-1d',
                todayHighlight: true,
                zIndexOffset: 1030
            });
            $("#modal-actualiza-hito .modal-footer .btn-primary").on("click", ActualizarHito);
            $("#fl-atributo option[value=-1]").prop("selected", true);
            $("#fl-atributo").on("change", flAtributoOnChange);
            $("#fl-busca").on("click", BuscarAtributo);
            $(".btn-catalogo").on("click", btnCatalogoOnClick);
        </script>
    </body>
</html>