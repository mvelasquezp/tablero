<nav id="sidebar">
    <div id="dismiss">
        <i class="fas fa-arrow-left"></i>
    </div>

    <div class="sidebar-header">
        <h3>Bienvenido, <?php echo e($usuario->des_alias); ?></h3>
    </div>

    <ul class="list-unstyled components">
        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <?php if(count($item->items) > 0): ?>
            <a href="#item-<?php echo e($item->id); ?>" data-toggle="collapse" aria-expanded="false"><i class="fas fa-caret-down"></i> <?php echo e($item->nombre); ?></a>
            <ul class="collapse list-unstyled" id="item-<?php echo e($item->id); ?>">
                <?php $__currentLoopData = $item->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="<?php echo e(url('intranet', [$item->url, $subitem->url])); ?>"><?php echo e($subitem->nombre); ?></a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
            <li>
                <a href="<?php echo e(url('intranet', [$item->url])); ?>"><?php echo e($item->nombre); ?></a>
            </li>
            <?php endif; ?>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <ul class="list-unstyled CTAs">
        <!--li>
            <a href="https://bootstrapious.com/tutorial/files/sidebar.zip" class="download"><i class="fas fa-cogs"></i> Opciones</a>
        </li-->
        <li>
            <a href="javascript:logout()" class="article"><i class="fas fa-sign-out-alt"></i> Salir</a>
        </li>
    </ul>
</nav>
<script type="text/javascript">
    function logout() {
        if(window.confirm("¿Desea salir del sistema? Tendrá que ingresar sus credenciales nuevamente la próxima vez.")) {
            location.href = "<?php echo e(url('login/logout')); ?>";
        }
    }
</script>